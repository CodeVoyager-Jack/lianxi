const loggerFactory = require('@docmirror/dev-sidecar/src/utils/util.logger')

const logger = loggerFactory.getLogger('gui')

module.exports = logger
