import { ref } from 'vue'

export const colorTheme = ref('dark')
