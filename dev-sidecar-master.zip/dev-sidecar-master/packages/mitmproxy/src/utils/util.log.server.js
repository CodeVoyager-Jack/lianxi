const loggerFactory = require('@docmirror/dev-sidecar/src/utils/util.logger')

const logger = loggerFactory.getLogger('server')

module.exports = logger
