// 需要时，在 package.json 中添加以下依赖:
// "devDependencies": {
//     "crypto-js": "^4.2.0"
// }

// const CryptoJs = require('crypto-js')
//
// const ret = CryptoJs.SHA256('111111111111')
// console.log(ret.toString(CryptoJs.enc.Base64))
// console.log(1 / 2)
