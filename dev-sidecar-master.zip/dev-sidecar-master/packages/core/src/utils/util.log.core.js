const loggerFactory = require('./util.logger')

const logger = loggerFactory.getLogger('core')

module.exports = logger
