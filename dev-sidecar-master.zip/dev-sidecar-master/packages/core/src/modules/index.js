module.exports = {
  server: require('./server'),
  proxy: require('./proxy'),
  plugin: require('./plugin'),
}
