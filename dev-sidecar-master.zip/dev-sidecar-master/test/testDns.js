console.log('www.baidu.com'.match('.*.baidu.com'))
